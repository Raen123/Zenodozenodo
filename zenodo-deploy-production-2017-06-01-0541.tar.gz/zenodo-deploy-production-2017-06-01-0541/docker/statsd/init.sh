#!/usr/bin/env bash
sh /usr/local/lib/node_modules/statsd-elasticsearch-backend/es-index-template.sh
